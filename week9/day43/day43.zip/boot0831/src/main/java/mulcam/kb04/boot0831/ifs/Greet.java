package mulcam.kb04.boot0831.ifs;

public interface Greet {
	//인사말 서비스
	public String greeting();
}
