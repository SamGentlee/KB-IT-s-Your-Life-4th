package mulcam.kb04.boot0831.ifs;

public class MorningGreet implements Greet {

	@Override
	public String greeting() {
		return "Good Morning";
	}

}
