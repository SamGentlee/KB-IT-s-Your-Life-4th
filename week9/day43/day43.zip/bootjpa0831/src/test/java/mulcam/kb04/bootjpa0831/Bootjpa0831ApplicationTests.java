package mulcam.kb04.bootjpa0831;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bootjpa0831ApplicationTests {

	@Test
	void contextLoads() {
	}

}
