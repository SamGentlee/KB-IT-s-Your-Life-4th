package mulcam.kb04.bootmvc0901;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bootmvc0901Application {

	public static void main(String[] args) {
		SpringApplication.run(Bootmvc0901Application.class, args);
	}

}
