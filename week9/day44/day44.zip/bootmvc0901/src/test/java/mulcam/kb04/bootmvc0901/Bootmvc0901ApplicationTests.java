package mulcam.kb04.bootmvc0901;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bootmvc0901ApplicationTests {

	@Test
	void contextLoads() {
	}

}
