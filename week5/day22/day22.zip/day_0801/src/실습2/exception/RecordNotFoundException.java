package 실습2.exception;

public class RecordNotFoundException extends Exception {
	
	public RecordNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
	public RecordNotFoundException(String msg) {
		super(msg);
	}
	
}
