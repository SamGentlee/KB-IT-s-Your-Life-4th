package cinema.exception;

public class TicketException extends Exception {
	public TicketException() {
		// TODO Auto-generated constructor stub
	}
	
	public TicketException(String msg) {
		super(msg);
	}
}
