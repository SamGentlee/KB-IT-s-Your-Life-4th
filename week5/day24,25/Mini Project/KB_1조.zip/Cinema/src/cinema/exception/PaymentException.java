package cinema.exception;

public class PaymentException  extends Exception{
	public PaymentException() {
		// TODO Auto-generated constructor stub
	}

	public PaymentException(String msg) {
		super(msg);
	}
}
