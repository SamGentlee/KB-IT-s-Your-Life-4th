package cinema.exception;

public class TheaterException extends Exception {
	public TheaterException() {
	}
	public TheaterException(String message) {
		super(message);
	}
}
