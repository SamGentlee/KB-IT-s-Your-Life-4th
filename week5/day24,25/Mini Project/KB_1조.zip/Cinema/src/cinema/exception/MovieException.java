package cinema.exception;

public class MovieException extends Exception {
	public MovieException() {
	}

	public MovieException(String message) {
		super(message);
	}
}
