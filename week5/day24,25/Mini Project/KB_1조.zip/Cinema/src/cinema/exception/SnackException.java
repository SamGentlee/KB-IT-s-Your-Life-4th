package cinema.exception;

public class SnackException extends Exception {
    public SnackException() {
    }
    public SnackException(String message) {
        super(message);
    }
}
