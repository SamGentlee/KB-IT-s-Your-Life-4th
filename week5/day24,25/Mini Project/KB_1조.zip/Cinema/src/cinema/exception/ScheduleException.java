package cinema.exception;

public class ScheduleException extends Exception {
	public ScheduleException() {
	}

	public ScheduleException(String message) {
		super(message);
	}
}
