package board.exception;

public class BoardException extends Exception {
	public BoardException() {
		// TODO Auto-generated constructor stub
	}
	public BoardException(String msg) {
		super(msg);
	}
}
