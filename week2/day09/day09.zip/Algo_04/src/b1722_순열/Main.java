package b1722_순열;
//474p
public class Main {

}
