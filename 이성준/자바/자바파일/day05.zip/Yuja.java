package day05;
//유자 + 설탕 
public class Yuja {
	private int yuja;
	private int sugar;
	
	//setter, getter구성하기
	public void setYuja(int y) {
		this.yuja=y;
	}
	public void setSugar(int s) {
		this.sugar=s;
	}
	public int getYuja() {
		return this.yuja;
	}
	public int getSugar() {
		return sugar;
	}

}///////////////////////////////
