/**
 * 
 */
/**
 * @author a
 *
 */
module Begin {
	requires java.desktop;
}