package my.app;
import java.awt.Color;

import javax.swing.*;
public class MyJoinPanel extends JPanel {
	
	public MyJoinPanel() {
		this.setBackground(Color.cyan);
	}

}
