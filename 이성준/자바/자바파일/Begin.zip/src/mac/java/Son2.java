package mac.java;
//Parent상속받기
//4가지 변수 출력하기
import window.java.*;

public class Son2 extends Parent {
	
	public void go() {
		System.out.println("publicVar: "+publicVar);
		System.out.println("protectedVar: "+protectedVar);
//		System.out.println("defaultVar: "+defaultVar); [x]
//		System.out.println("privateVar: "+privateVar); [x]
	}
	public static void main(String[] args) {
		Son2 s=new Son2();
		s.go();
	}

}
