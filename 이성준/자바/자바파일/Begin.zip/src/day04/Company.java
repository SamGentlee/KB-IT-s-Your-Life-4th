package day04;
//속성 3~4, 기능: 2개 이상
//JobkoreaApp에서 객체 생성해서 메서드 호출하기
//배열에 회사객체 저장후 반복문 돌려 출력하기
public class Company {

}
