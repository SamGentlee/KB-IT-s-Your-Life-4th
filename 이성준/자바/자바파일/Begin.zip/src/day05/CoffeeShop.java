package day05;

public class CoffeeShop {

	public static void main(String[] args) {
		VendingMachine vm=new VendingMachine();
		// 밀크 커피 내오기
		vm.makeTea(2,1,1);
		// 설탕 커피 내오기
		vm.makeTea(1, 1);
		//블랙 커피 내오기
		String str=vm.makeTea(2);
		System.out.println(str);
		
		//크림 커피 내오기
		vm.makeTea((short)1,3);
		
		//유자차 내오기
		Yuja yj=new Yuja();
		yj.setYuja(2);
		yj.setSugar(3);
		vm.makeTea(yj);

	}

}
