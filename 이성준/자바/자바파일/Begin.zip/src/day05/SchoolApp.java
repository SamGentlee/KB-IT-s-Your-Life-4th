package day05;

public class SchoolApp {

	public static void main(String[] args) {
		// 단위 테스트
		Student st = new Student();
		st.printInfo();
		st.setNo(1);
		st.setName("홍길동");
		st.setClassName("자바반");

		st.printInfo();

		String cname = st.getClassName();
		System.out.println(cname);

		Teacher tc = new Teacher();
		tc.setNo(100);
		tc.setName("김교사");
		tc.setSubject("C");

		tc.printInfo();
		// 문제1]학생 객체를 2개 더 생성하고...
		// 각각 이름,학번,학급 값을 넣어준뒤...
		// 3명의 학생을 배열에 저장하자.
		// for루프 돌리면서 저장된 학생 객체들의
		// 정보를 출력해보자.
		
		Student st2=new Student();
		st2.setNo(2);
		st2.setName("이창수");
		st2.setClassName("빅데이터반");
		st2.printInfo();
		
		
		Student st3=new Student();
		st3.setNo(3);
		st3.setName("박혜수");
		st3.setClassName("백엔드개발자반");
		st3.printInfo();
		
		Student[] arr1= {st, st2, st3};
		
		Student[] stu = new Student[3];
		stu[0]=st;
		stu[1]=st2;
		stu[2]=st3;

		
		for(int i=0;i<arr1.length;i++) {
			arr1[i].printInfo();
		}
		System.out.println("*****************");
		//확장 for루프로 출력하기
		for(Student s:stu) {
			s.printInfo();
		}
		
		

	}

}
