package pack.demo;

public class My2 {
	public void sub2() {
		System.out.println("My2 class's sub2()");
	}
}
