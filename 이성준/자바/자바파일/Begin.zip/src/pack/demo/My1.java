package pack.demo;

public class My1 {
	public void sub1() {
		System.out.println("My1 class's sub1()");
	}
}
