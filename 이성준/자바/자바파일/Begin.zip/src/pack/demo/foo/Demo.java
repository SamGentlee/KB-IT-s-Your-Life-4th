package pack.demo.foo;

public class Demo {
	public void demo1() {
		System.out.println("Demo class's demo1()");
	}
}
