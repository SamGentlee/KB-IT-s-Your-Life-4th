package day07;
import javax.swing.*;
public class AnimalTest {

	public static void main(String[] args) {
		String type=JOptionPane.showInputDialog("동물 종류 입력");
		String count=JOptionPane.showInputDialog("새끼 수 입력");
		if(type==null|| count==null) return;
		// == : 기본자료형=> 값을 비교
		//		참조형 => 주소값을 비교
		//Object의 equals()메서드: 원래 주소값을 비교한다
		//boolean	equals(Object anObject)
		//:String 클래스에서 equals()메서드: 문자열의 내용 비교로 재정의 되었다.
		
		Animal an=null;
		if(type.equals("강아지")) {
			an=new Dog();
		}else if(type.equals("고양이")) {
			an = new Cat();
		}else if(type.equals("오리")) {
			an = new Duck();
		}
		else {
			System.out.println("그런 동물 안키워요~~");
			return;
		}
		an.crySound();
		an.getBaby(Integer.parseInt(count));

	}

}


