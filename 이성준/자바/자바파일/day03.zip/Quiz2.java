package day03;

public class Quiz2 {

	public static void main(String[] args) {
		String value="12345!";
		boolean isNumber=true;
		for(int i=0;i<value.length();i++) {
			char c=value.charAt(i);
			if(!(c>='0'&& c<='9')) {
				isNumber=false;
				break;
			}
		}//for------
		
		if(!isNumber) {
			System.out.println("숫자가 아니에요");
		}else {
			System.out.println("숫자가 맞아요");
		}
		
		

	}

}
