package day03;

import java.util.Scanner;

public class Quiz1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		int sum=0;
		while (num > 0) {
			 //sum += num % 10;
			 int n=num%10;
			 sum+=n;
			 num /= 10;
			 System.out.print(n+" ");
		}//while----
		System.out.println("\nsum="+sum);

	}

}
