package day01;

import java.io.*;
import java.util.ArrayList;

public class DataSampling {

	public static void main(String[] args) throws IOException {
		String fName = "경기도_광주시_호수_20220913.csv";
		File file = new File(fName);

		BufferedReader br = new BufferedReader(new FileReader(file));

		String str = "";
		ArrayList<String[]> strArr = new ArrayList<>();
		while ((str = br.readLine()) != null) {
			strArr.add(str.split(",,"));
		}
		for (String[] strings : strArr) {
			for (String strings2 : strings) {
				System.out.print(strings2);
			}
			System.out.println();
		}
		br.close();
	}

}
