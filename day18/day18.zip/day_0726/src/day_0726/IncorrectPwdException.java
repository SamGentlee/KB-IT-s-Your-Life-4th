package day_0726;

public class IncorrectPwdException extends Exception {
	
	public IncorrectPwdException() {
		
	}

	public IncorrectPwdException(String message) {
		super(message);
	}
	
	
}
