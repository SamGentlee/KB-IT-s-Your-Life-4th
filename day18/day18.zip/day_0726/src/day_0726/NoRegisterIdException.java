package day_0726;

public class NoRegisterIdException extends Exception {
	
	public NoRegisterIdException() {
		
	}
	public NoRegisterIdException(String message) {
		super(message);
	}
}
