package day_0725;
/** 그리기 기능을 정의 인터페이스 */
public interface MyDrawable {
	
	/** 자기자신을 그릴때 호출하는 메서드 */
	public abstract void draw();
	
}
