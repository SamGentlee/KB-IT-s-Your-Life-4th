package workshop;

public class 미등록물건Exception extends Exception {

}
