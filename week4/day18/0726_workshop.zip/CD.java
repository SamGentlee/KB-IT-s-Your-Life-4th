package workshop;

public class CD extends MyItem {

	public CD(int itemNo, String title, int price, String singer, int quantity) {
		super(itemNo, title, price, quantity);
	}

}
