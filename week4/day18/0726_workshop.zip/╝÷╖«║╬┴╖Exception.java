package workshop;

public class 수량부족Exception extends Exception {

}
