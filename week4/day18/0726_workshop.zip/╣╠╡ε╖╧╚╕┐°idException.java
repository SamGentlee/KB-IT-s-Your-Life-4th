package workshop;

public class 미등록회원idException extends Exception {

}
