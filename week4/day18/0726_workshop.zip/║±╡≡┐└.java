package workshop;

public class 비디오 extends MyItem {

	public 비디오(int itemNo, String title, int price, String production, int quantity) {
		super(itemNo, title, price, quantity);
	}

}
