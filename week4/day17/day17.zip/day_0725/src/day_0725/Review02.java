package day_0725;

public class Review02 {
	int i;//멤버변수(필드) - 필드는 객체 생성시 자동으로 기본값 초기화
	public static void main(String[] args) {
		int i = 0;//지역변수(로컬) - 초기화 안하고 선언하면 사용 불가능
		System.out.println(i); //지역변수로 똑같은 i 가 선언되었고 초기화가 안되면 오류
	}
}
