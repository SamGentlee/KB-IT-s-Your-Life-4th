package day_0725;

public class ShapeExam {
	public static void main(String[] args) {
		MyShape ms = new MyLine(0,0,5,5);
		System.out.println(ms.draw());
	}
}
