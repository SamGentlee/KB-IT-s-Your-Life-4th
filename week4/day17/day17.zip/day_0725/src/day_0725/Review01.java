package day_0725;

public class Review01 {

	public static void main(String[] args) {
		int i = 100;
		long l = 200;
		float f = l;
		long l2 = (long)f;
//		boolean b = (boolean)i; //boolean타입은 숫자가 아니라서 컴파일 오류
//		String s = (String)i;  //wrapper를 통한 변환만 가능하다
//		큰타입 = 큰타입 - 작은타입;
//		int j = 1.0 + 2; //작은타입 = 큰타입+작은타입 X
	}

}
