package web0817_mvc.exception;

public class DuplicatedIdException extends Exception {

}
