package HW_07_1반_이성준.exception;

public class DuplicatedIdException extends Exception {
	public DuplicatedIdException() {
		// TODO Auto-generated constructor stub
	}
	public DuplicatedIdException(String msg) {
		super(msg);
	}
	
}
