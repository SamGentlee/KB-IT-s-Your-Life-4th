package HW_07_1반_이성준.exception;

public class RecordNotFoundException extends Exception {

	public RecordNotFoundException() {
	}
	public RecordNotFoundException(String message) {
		super(message);
	}

}
