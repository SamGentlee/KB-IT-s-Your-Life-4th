package board.exception;

public class DuplicatedIdException extends Exception {

}
