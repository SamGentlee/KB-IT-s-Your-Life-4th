package member.exception;

public class DuplicatedIdException extends Exception {
	public DuplicatedIdException() {
		// TODO Auto-generated constructor stub
	}
	public DuplicatedIdException(String msg) {
		super(msg);
	}
}
