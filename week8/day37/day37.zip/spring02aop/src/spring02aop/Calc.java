package spring02aop;

public interface Calc {
	public long factorial(long num);
}
