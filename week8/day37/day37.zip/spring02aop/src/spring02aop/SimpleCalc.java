package spring02aop;

public interface SimpleCalc {
	public int plus(int i, int j);
	public int minus(int i, int j);
}
