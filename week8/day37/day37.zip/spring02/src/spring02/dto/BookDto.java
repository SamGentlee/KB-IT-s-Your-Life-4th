package spring02.dto;

public class BookDto {
}
