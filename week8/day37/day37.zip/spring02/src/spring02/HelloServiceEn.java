package spring02;

public class HelloServiceEn extends HelloService{
	@Override
	public String hello() {
		return "Hello";
	}
}
