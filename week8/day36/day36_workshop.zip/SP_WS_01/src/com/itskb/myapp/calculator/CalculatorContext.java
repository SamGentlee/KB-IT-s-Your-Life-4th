package com.itskb.myapp.calculator;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

@Component
@ComponentScan(basePackages = {"com.itskb.myapp.calculator"})
public class CalculatorContext {
	
}
