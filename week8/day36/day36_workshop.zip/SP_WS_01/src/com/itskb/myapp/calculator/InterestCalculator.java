package com.itskb.myapp.calculator;

public interface InterestCalculator {
	public double calculate(int amount);
}
