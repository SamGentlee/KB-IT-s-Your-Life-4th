package spring01;

public class MyLog {
	
	public void log(String msg) {
		System.out.println("ȭ�� : "+msg);
	}
}
