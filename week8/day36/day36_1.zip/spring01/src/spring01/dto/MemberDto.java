package spring01.dto;

public class MemberDto {
	
	private String id;
	private String passwd;
	
}
