package spring01;

public class HelloServiceEn extends HelloService{
	
	@Override
	public String hello() {
		return "Hi";
	}
}
