package spring01;

import java.util.List;

import spring01.dto.MemberDto;

public class MemberDaoMySqlImpl implements MemberDao {

	@Override
	public void add(MemberDto dto) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<MemberDto> list() {
		// TODO Auto-generated method stub
		return null;
	}

}
