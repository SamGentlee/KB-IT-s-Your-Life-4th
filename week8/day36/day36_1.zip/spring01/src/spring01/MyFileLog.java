package spring01;

public class MyFileLog extends MyLog{
	
	@Override
	public void log(String msg) {
		System.out.println("���� : "+msg);
	}
	
}
