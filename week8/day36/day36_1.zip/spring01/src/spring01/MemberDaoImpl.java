package spring01;

import java.util.List;

import spring01.dto.MemberDto;

public class MemberDaoImpl implements MemberDao {

	@Override
	public void add(MemberDto dto) {

	}

	@Override
	public List<MemberDto> list() {
		return null;
	}

}
