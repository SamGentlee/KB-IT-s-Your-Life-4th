package spring011;


public class MemberDto {
	
	private String id;
	private String passwd;
	
}
