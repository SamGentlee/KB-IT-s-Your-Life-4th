package spring011;


import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class MemberDaoImpl implements MemberDao {

	@Override
	public void add(MemberDto dto) {

	}

	@Override
	public List<MemberDto> list() {
		return null;
	}

}
